import React from "react";

// The landing page doesn't need a complex layout wrapper, 
// but we follow the pattern.
export default [];